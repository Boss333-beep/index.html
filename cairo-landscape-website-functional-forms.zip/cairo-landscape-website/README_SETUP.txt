CAIRO LANDSCAPE WEBSITE - FORM SETUP NOTES

The quote form and contact form are now connected to FormSubmit:
https://formsubmit.co/

Current delivery email:
cairolandscape@outlook.com

Important first-live-use step:
1. Publish the website to your hosting/domain.
2. Submit each form once from the live website.
3. Open the activation email sent by FormSubmit and click the confirmation link.
4. After activation, future submissions will be delivered to cairolandscape@outlook.com.

Notes:
- The quote form supports image attachments using multipart/form-data.
- FormSubmit documentation says file uploads are supported, with a combined 10MB limit.
- If you want a branded thank-you page after submission, add a full absolute URL in a hidden _next field after the final site URL is known.
- Right now, after submit, visitors will see FormSubmit's confirmation page.