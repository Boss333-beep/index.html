document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('header nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => nav.classList.toggle('open'));
  }

  document.querySelectorAll('form[data-local-demo="true"][data-success]').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const noteId = form.getAttribute('data-success');
      const note = document.getElementById(noteId);
      if (note) {
        note.classList.add('show');
        note.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
      form.reset();
    });
  });
});
